<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-tags"></i> <?php echo e($pageTitle); ?></h1>
        </div>
    </div>
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="tile">
                <h3 class="tile-title"><?php echo e($subTitle); ?></h3>
                <form action="<?php echo e(route('admin.slides.update')); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="tile-body">
                        <div class="form-group">
                            <label class="control-label" for="title">Title <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="title" id="title" value="<?php echo e(old('name', $slide->title)); ?>"/>
                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <input type="hidden" name="id" value="<?php echo e($slide->id); ?>">
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="sub_title">Sub Title <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('sub_title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sub_title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="sub_title" id="sub_title" value="<?php echo e(old('sub_title', $slide->sub_title)); ?>"/>
                            <?php if ($errors->has('sub_title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sub_title'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="description">Description</label>
                            <textarea class="form-control" rows="4" name="description" id="description"><?php echo e(old('description', $slide->description)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="button_text">Button Text<span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('button_text')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('button_text'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="button_text" id="button_text" value="<?php echo e(old('button_text',$slide->button_text)); ?>"/>
                            <?php if ($errors->has('button_text')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('button_text'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="button_link">Button Link<span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('button_link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('button_link'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="button_link" id="button_link" value="<?php echo e(old('button_link',$slide->button_link)); ?>"/>
                            <?php if ($errors->has('button_link')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('button_link'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>                        
                         <div class="form-group">
                            <div class="row">
                                <div class="col-md-2">
                                    <?php if($slide->image != null): ?>
                                        <figure class="mt-2" style="width: 80px; height: auto;">
                                            <img src="<?php echo e(asset('storage/'.$slide->image)); ?>" id="slideImage" class="img-fluid" alt="img">
                                        </figure>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-10">
                                    <label class="control-label">slide Image</label>
                                    <input class="form-control <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="file" id="image" name="image"/>
                                    <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Save Slide</button>
                        &nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" href="<?php echo e(route('admin.slides.index')); ?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel_Flipmart_ecommerce\resources\views/admin/slides/edit.blade.php ENDPATH**/ ?>