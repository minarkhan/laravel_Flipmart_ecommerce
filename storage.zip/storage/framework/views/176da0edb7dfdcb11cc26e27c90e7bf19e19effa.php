<?php $__env->startSection('title'); ?> <?php echo e($pageTitle); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-briefcase"></i> <?php echo e($pageTitle); ?></h1>
        </div>
    </div>
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="tile">
                <h3 class="tile-title"><?php echo e($subTitle); ?></h3>
                <form action="<?php echo e(route('admin.shippings.store')); ?>" method="POST" role="form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        
                    <div class="tile-body">
                        <div class="form-group">
                            <label class="control-label" for="zone_name">zone_name <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('zone_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zone_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="zone_name" id="zone_name" value="<?php echo e(old('zone_name')); ?>"/>
                            <?php if ($errors->has('zone_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zone_name'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="zone_name">zone_regions <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('zone_regions')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zone_regions'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="zone_regions" id="zone_regions" value="<?php echo e(old('zone_regions')); ?>"/>
                            <?php if ($errors->has('zone_regions')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zone_regions'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="method">Shipping Method <span class="m-l-5 text-danger"> *</span></label>
                             <select class="form-control"  name="method" id="method">
                                <option value="Flat Rate">Flat Rate</option>
                                <option value="Free Shipping">Free Shipping</option>
                                <option value="Local Pickup">Local Pickup</option>
                            </select>
                            <?php if ($errors->has('method')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('method'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="price">Rate <span class="m-l-5 text-danger"> *</span></label>
                            <input class="form-control <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" name="price" id="price" value="<?php echo e(old('price')); ?>" placeholder="Shipping price" />
                            <?php if ($errors->has('price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('price'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="status">status <span class="m-l-5 text-danger"> *</span></label>
                            <select class="form-control"  name="status" id="status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                            <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="tile-footer">
                        <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Save Shipping</button>
                        &nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" href="<?php echo e(route('admin.shippings.index')); ?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel_Flipmart_ecommerce\resources\views/admin/shipping/create.blade.php ENDPATH**/ ?>