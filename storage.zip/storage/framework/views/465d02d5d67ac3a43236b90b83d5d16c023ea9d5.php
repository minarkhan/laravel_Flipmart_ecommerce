<!-- For demo purposes – can be removed on production --> 

<!-- For demo purposes – can be removed on production : End --> 

<!-- JavaScripts placed at the end of the document so the pages load faster --> 
<script src="<?php echo e(asset('assets/website')); ?>/js/jquery-1.11.1.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/bootstrap.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/bootstrap-hover-dropdown.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/owl.carousel.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/echo.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/jquery.easing-1.3.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/bootstrap-slider.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/jquery.rateit.min.js"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/website')); ?>/js/lightbox.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/bootstrap-select.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/wow.min.js"></script> 
<script src="<?php echo e(asset('assets/website')); ?>/js/scripts.js"></script><?php /**PATH C:\xampp\htdocs\laravel\Laravel-E-commerce-Part-12\resources\views/site/partials/scripts.blade.php ENDPATH**/ ?>